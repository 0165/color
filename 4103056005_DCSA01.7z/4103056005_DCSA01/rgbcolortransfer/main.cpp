#include <stdio.h>
//#include <iostream>
#include <math.h>
#include <iomanip>
#include "MyBMP.h"
//===============================================================================
//using namespace std;
//===============================================================================
struct  Mean
{
    float redM;
    float blueM;
    float greenM;
    float redStd;
    float blueStd;
    float greenStd;    
};
//===============================================================================
void resetMean(Mean *);
void getMean(BMP , const char *OutputName,Mean *);
void getBin(const unsigned int *,char*);
//===============================================================================
int main(int argc, char** argv)
{
	int i=0;
	char name[255];
	BMP Img;
	Mean myMean;
    resetMean(&myMean);
    printf("give me the name of openfile(ex: 123.bmp):\n");
	scanf("%s",name);
    Img.ReadFromFile(name);  //Ū�������ɦW�r
	while(*(name+i)!='.')
		i++;
	strcpy(name+i,".txt");
	getMean(Img, name,&myMean);
	
	return 0;
}
//===============================================================================
void getMean(BMP Img_In, const char *OutputName,Mean * myMean)
{
    FILE *outfile;
    char word[33];
    int i=0,j=0;
    for(i=0; i<Img_In.TellHeight(); i++)
    {
        for(j=0; j<Img_In.TellWidth(); j++)
        {
            RGBApixel NewPixel = Img_In.GetPixel(i, j);  //Ū����@�ӹ������c�CP.S.�]�i�H�ۦ�令��Ū����(R,G,B)�}�C��A�A�����ΡC
            myMean->redM += (float)NewPixel.Red;
            myMean->blueM += (float)NewPixel.Blue;
            myMean->greenM += (float)NewPixel.Green;
        }
    }
    myMean->redM /= (i*j);
    myMean->blueM /= (i*j);
    myMean->greenM /= (i*j);
    for(i=0; i<Img_In.TellHeight(); i++)
    {
        for(j=0; j<Img_In.TellWidth(); j++)
        {
            RGBApixel NewPixel = Img_In.GetPixel(i, j);  //Ū����@�ӹ������c�CP.S.�]�i�H�ۦ�令��Ū����(R,G,B)�}�C��A�A�����ΡC
            myMean->redStd+=powf(((float)NewPixel.Red)-myMean->redM,2.0);
            myMean->blueStd+=powf(((float)NewPixel.Blue)-myMean->blueM,2.0);
            myMean->greenStd+=powf(((float)NewPixel.Green)-myMean->greenM,2.0);
        }
    }
    myMean->redStd = sqrt((myMean->redStd/(i*j)));
    myMean->blueStd = sqrt((myMean->blueStd/(i*j)));
    myMean->greenStd = sqrt((myMean->greenStd/(i*j)));
    
    outfile = fopen(OutputName,"w");

    getBin((unsigned*)&myMean->redM,word);
    fprintf(outfile,"%.6f\n%s\n",myMean->redM,word);
    getBin((unsigned*)&myMean->greenM,word);
    fprintf(outfile,"%.6f\n%s\n",myMean->greenM,word); 
    getBin((unsigned*)&myMean->blueM,word);
    fprintf(outfile,"%.6f\n%s\n",myMean->blueM,word);   
      
    getBin((unsigned*)&myMean->redStd,word);
    fprintf(outfile,"%.6f\n%s\n",myMean->redStd,word);  
    getBin((unsigned*)&myMean->greenStd,word);
    fprintf(outfile,"%.6f\n%s\n",myMean->greenStd,word);
    getBin((unsigned*)&myMean->blueStd,word);
    fprintf(outfile,"%.6f\n%s\n",myMean->blueStd,word); 
    
    
    fclose(outfile);
}
//===============================================================================
void resetMean(Mean *myMean){
    myMean->redM=0.0;
    myMean->blueM=0.0;
    myMean->greenM=0.0;
    myMean->redStd=0.0;
    myMean->blueStd=0.0;
    myMean->greenStd=0.0;
}
//===============================================================================
void getBin(const unsigned int * num,char* word){
    unsigned int temp=*num;
    int i=0;
    for(i=31;i >= 0;i--){
        *(word+i) = (temp & 0x01) + 48;
        temp=temp >> 1;
    }
}
//===============================================================================