#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iomanip>
#include "MyBMP.h"
//===============================================================================
#define theSeed 100
//===============================================================================
struct myPoint{
    int r;
    int g;
    int b;
};
//===============================================================================
FILE *file;
//===============================================================================
void unEmd(const int,char *,BMP);
//===============================================================================
int main(int argc, char** argv)
{
    char name[255];
    int n=0;
    BMP img;
    printf("give me the name of sourse(ex: s1.bmp):\n");
    scanf("%s",name);
    img.ReadFromFile(name);
    while(n<3){
        printf("give me the number of n (2<n<=%d):\n",img.TellWidth()*img.TellHeight());
        scanf("%d",&n);
    }
    strcpy(name+strlen(name)-3,"txt\0");
    unEmd(n,name,img);
    return 0;
}
//===============================================================================
void unEmd(const int n,char *name,BMP img){
    int i=0,j=0,cc=0,count=0;
    FILE *file;
    file=fopen(name,"w");
    while((i*img.TellHeight()+j+n)<= img.TellWidth() * img.TellHeight() ){
        for(cc=0;cc<n;j++,cc++){
            if(j==img.TellHeight()){    j=0;   i++;    }
            count+=img.GetPixel(i, j).Red * (cc+1);
        }
        count%=(2*n+1);
        fprintf(file,"%d, ",count);
        count=0;
    }
    i=0;j=0;
    while((i*img.TellHeight()+j+n)<= img.TellWidth() * img.TellHeight() ){
        for(cc=0;cc<n;j++,cc++){
            if(j==img.TellHeight()){    j=0;   i++;    }
            count+=img.GetPixel(i, j).Green * (cc+1);
        }
        count%=(2*n+1);
        fprintf(file,"%d, ",count);
        count=0;
    }
    i=0;j=0;
    while((i*img.TellHeight()+j+n)<= img.TellWidth() * img.TellHeight() ){
        for(cc=0;cc<n;j++,cc++){
            if(j==img.TellHeight()){    j=0;   i++;    }
            count+=img.GetPixel(i, j).Blue * (cc+1);
        }
        count%=(2*n+1);
        fprintf(file,"%d, ",count);
        count=0;
    }
    fclose(file);
}
//===============================================================================