#include <iostream>
#include <fstream>
#include "MyBMP.h"

using namespace std;

void makecsv(BMP Img_In, const char *OutputName);

int main(int argc, char** argv)
{
	int i=0;
	char name[255];
	BMP Img;
	printf("give me the name of openfile(ex: 123.bmp):\n");
	scanf("%s",name);
    Img.ReadFromFile(name);  //Ū�������ɦW�r
	while(*(name+i)!='.')
		i++;
	strcpy(name+i,".csv");
	makecsv(Img, name);
	
	return 0;
}

void makecsv(BMP Img_In, const char *OutputName)
{
    fstream outfile;
    outfile.open(OutputName,ios::out);
    int k=0;
    for(int i=0; i<Img_In.TellHeight(); i++)
    {
        for(int j=0; j<Img_In.TellWidth(); j++,k++)
        {
            RGBApixel NewPixel = Img_In.GetPixel(i, j);  //Ū����@�ӹ������c�CP.S.�]�i�H�ۦ�令��Ū����(R,G,B)�}�C��A�A�����ΡC 
            outfile << k << ',' << (int)NewPixel.Red << ',' << (int)NewPixel.Green << ',' << (int)NewPixel.Blue << '\n'; 
        }
    }
}
