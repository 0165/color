#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iomanip>
#include "MyBMP.h"
//===============================================================================
#define theSeed 100
//===============================================================================
struct myPoint{
    int r;
    int g;
    int b;
};
//===============================================================================
FILE *file;
//===============================================================================
void getAllPoint(myPoint*, BMP*);
void saveBMP(myPoint*, BMP*,char *);
void cacul(int *, const int);
void Emd(const int, myPoint*,BMP*,char *);
//===============================================================================
int main(int argc, char** argv)
{
    char name[255];
    int n=0;
    BMP img;
    srand(theSeed);
    printf("give me the name of sourse(ex: s1.bmp):\n");
    scanf("%s",name);
    img.ReadFromFile(name);
    myPoint *ary=new myPoint[img.TellWidth() *img.TellHeight()];
    while(n<3 || n>img.TellWidth()*img.TellHeight()){
        printf("give me the number of n (2<n<=%d):\n",img.TellWidth()*img.TellHeight());
        scanf("%d",&n);
    }
    getAllPoint(ary,&img);
    strcpy(name+strlen(name)-4,".txt\0");
    Emd(n,ary,&img,name);
    strcpy(name+strlen(name)-4,"_st.bmp\0");
    saveBMP(ary,&img,name);
    delete ary;
    return 0;
}
//===============================================================================
void getAllPoint(myPoint* ary, BMP* img){
    int i=0,j=0;
    for(i=0; i<img->TellWidth(); i++)
    {
        for(j=0; j<img->TellHeight(); j++)
        {
            RGBApixel NewPixel = img->GetPixel(i, j);
            ary[i*img->TellHeight()+j].r=NewPixel.Red;
            ary[i*img->TellHeight()+j].g=NewPixel.Green;
            ary[i*img->TellHeight()+j].b=NewPixel.Blue;
        }
    }
}
//===============================================================================
void Emd(const int n, myPoint* ary,BMP* img,char *name){
    int i=0,j=0,ii=0,jj=0,cc=0;
    int *group=new int[n];
    file=fopen(name,"w");
    while((i*img->TellHeight()+j+n)<= img->TellWidth() * img->TellHeight() ){
        ii=i;   jj=j;
        for(cc=0;cc<n;cc++,jj++){
            if(jj==img->TellHeight()){    jj=0;   ii++;    }
            group[cc]=ary[ii*img->TellHeight()+jj].r;
        }
        cacul(group,n);
        for(cc=0;cc<n;cc++,j++){
            if(j==img->TellHeight()){    j=0;   i++;    }
            ary[i*img->TellHeight()+j].r=group[cc];
        }
    }
    i=0;j=0;
    while((i*img->TellHeight()+j+n)<= img->TellWidth() * img->TellHeight() ){
        ii=i;   jj=j;
        for(cc=0;cc<n;cc++,jj++){
            if(jj==img->TellHeight()){    jj=0;   ii++;    }
            group[cc]=ary[ii*img->TellHeight()+jj].g;
        }
        cacul(group,n);
        for(cc=0;cc<n;cc++,j++){
            if(j==img->TellHeight()){    j=0;   i++;    }
            ary[i*img->TellHeight()+j].g=group[cc];
        }
    }
    i=0;j=0;
    while((i*img->TellHeight()+j+n)<= img->TellWidth() * img->TellHeight() ){
        ii=i;   jj=j;
        for(cc=0;cc<n;cc++,jj++){
            if(jj==img->TellHeight()){    jj=0;   ii++;    }
            group[cc]=ary[ii*img->TellHeight()+jj].b;
        }
        cacul(group,n);
        for(cc=0;cc<n;cc++,j++){
            if(j==img->TellHeight()){    j=0;   i++;    }
            ary[i*img->TellHeight()+j].b=group[cc];
        }
    }
    fclose(file);
    delete group;
}
//===============================================================================
void cacul(int *group, const int n){
    int i=0,f=0,s=0,d=rand()%(2*n+1);
    fprintf(file,"%d, ",d);
LAB:  
    f=0;    s=0;    i=0;
    for(i=0;i<n;i++)    f=f+group[i]*(i+1);
    f=f % (2*n+1);
    if(f==d)    return void();
    
    s=d-f;
    if(s>0) s=s%(2*n+1);
    else    s=s+2*n+1;

    if(s<=n)   group[s-1]+=1;
    else{       s=2*n+1-s;    group[s-1]-=1; }
    if(group[s-1]>255){ group[s-1]=254; goto LAB;  }
    if(group[s-1]<0){    group[s-1]=1;    goto LAB;  }    
}
//===============================================================================
void saveBMP(myPoint* ary,BMP* img,char *name){
    int i,j;
    RGBApixel NewPixel;
    BMP out;
    out.SetSize(img->TellWidth() ,img->TellHeight());
    out.SetBitDepth(24);
    for(i=0; i<img->TellWidth(); i++)
    {
        for(j=0; j<img->TellHeight(); j++)
        {
            NewPixel.Red=ary[i*img->TellHeight()+j].r;
            NewPixel.Green=ary[i*img->TellHeight()+j].g;
            NewPixel.Blue=ary[i*img->TellHeight()+j].b;
            out.SetPixel(i, j, NewPixel);
        }
    }
    out.WriteToFile(name);
}
//===============================================================================